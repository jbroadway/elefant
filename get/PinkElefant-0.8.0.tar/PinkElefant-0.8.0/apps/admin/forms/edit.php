; <?php /*

[title]

not empty = 1

[layout]

skip_if_empty = 1
exists = "layouts/%s.html"

[body]

not empty = 1

; */ ?>