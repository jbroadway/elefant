<?php

/**
 * Fields:
 *
 * id
 * title
 * head (for additional script/style/meta includes)
 * layout
 * body
 */
class Webpage extends Model {}

?>